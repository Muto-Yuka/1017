#pragma once

static const int WINDOWS_X = 1920;
static const int WINDOWS_Y = 1080;






